const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const dosyalar = [
    'izlenecekDigerYapimlar',
    'izlenecekDiziler',
    'izlenecekFilmler',
    'izlenenDigerYapimlar',
    'izlenenDiziler',
    'izlenenFilmler'
];

dosyalar.forEach(dosya => {
    // Filmleri getir
    app.get('/' + dosya, (req, res) => {
        fs.readFile(dosya + '.json', (err, data) => {
            if (err) throw err;
            let filmler = JSON.parse(data);
            res.send(filmler);
        });
    });

    // Film ekle
    app.post('/' + dosya, (req, res) => {
        fs.readFile(dosya + '.json', (err, data) => {
            if (err) throw err;
            let filmler = JSON.parse(data);
            filmler.push(req.body);
            fs.writeFile(dosya + '.json', JSON.stringify(filmler), err => {
                if (err) throw err;
                res.send('Film eklendi.');
            });
        });
    });

    // Film sil
    app.delete('/' + dosya + '/:index', (req, res) => {
        fs.readFile(dosya + '.json', (err, data) => {
            if (err) throw err;
            let filmler = JSON.parse(data);
            filmler.splice(req.params.index, 1);
            fs.writeFile(dosya + '.json', JSON.stringify(filmler), err => {
                if (err) throw err;
                res.send('Film silindi.');
            });
        });
    });
});

app.listen(3000, () => console.log('Sunucu 3000 portunda çalışıyor.'));
